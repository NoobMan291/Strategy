package Abilities;
import Monsters.*;
public interface Ability {
}
